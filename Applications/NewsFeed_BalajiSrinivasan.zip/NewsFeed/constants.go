package main

const (
	upvote   = "UPVOTE"
	downvote = "DOWNVOTE"
)
